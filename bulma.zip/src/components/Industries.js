import "./Industries.css";

function Industries() {
  return (
    <div className="industries">
      <p></p>
    </div>
  );
}
export default Industries;
