import React, { useState } from "react";
import "./Navbar.css";

function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      <nav className={`navbar ${isMenuOpen ? "nav-open" : ""}`}>
        <div className="navbar-menu">
          <a href="#home" onClick={closeMenu}>
            <img
              src="https://d1xzdqg8s8ggsr.cloudfront.net/651e4a1a203962f3b10ddba7/d651b0eb-4743-4d38-b15f-274b7ac3c1b7_1696561304016730490"
              alt="Brand Logo"
              className="brand-image"
            />
          </a>
          <button className="nav-toggle" onClick={toggleMenu}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </nav>
      {/* Add the content of your page here */}
    </>
  );
}

export default Navbar;
