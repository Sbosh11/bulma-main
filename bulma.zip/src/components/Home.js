import "./Home.css";

function Home() {
  return (
    <div className="home">
      <p></p>
    </div>
  );
}
export default Home;
