import "./Industries.css";

function Industries() {
  return (
    <div className="industries">
      <p>Industries</p>
    </div>
  );
}
export default Industries;
