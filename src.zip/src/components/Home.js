import "./Home.css";

function Home() {
  return (
    <div className="home">
      <p>Home</p>
    </div>
  );
}
export default Home;
