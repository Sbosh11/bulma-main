import "./Services.css";

function Services() {
  return (
    <div className="services">
      <p>Services</p>
    </div>
  );
}
export default Services;