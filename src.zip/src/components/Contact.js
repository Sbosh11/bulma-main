import "./Industries.css";

function Industries() {
  return (
    <div className="industries">
      <p>Contact</p>
    </div>
  );
}
export default Industries;
