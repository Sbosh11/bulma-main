//import logo from "./logo.svg";
import "./App.css";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Home from "./components/Home";
import Industries from "./components/Industries";
import Navbar from "./components/Navbar";
import Cases from "./components/Cases";
//import Contact from "./components/Contact";
const router = createBrowserRouter([
  {
    element: <Navbar />,
    children: [
      {
        path: "/",
        element: <Home />,
      },
      {
        path: "/Industries",
        element: <Industries />,
      },
      {
        path: "/Cases",
        element: <Cases />,
      },
    ],
  },
]);

function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
